import PE3

l1 = show (function [Trig 2 (Power 0) (Sin (Polynomial [(1, Power 0)])), Const 2] 1)
l2 = show (derivative [Pw 3 (Power 2), Pw 1 (Power 1)])

main = do
    putStrLn l1
    putStrLn l2
